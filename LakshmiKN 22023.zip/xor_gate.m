clc;
clear;
clear;
function f=xor(x,y)
if x==1 
    if y==0 
        if x==0 
            if y==1
   disp(1);
else
   disp(0);
            end
        end
    end
end
end
