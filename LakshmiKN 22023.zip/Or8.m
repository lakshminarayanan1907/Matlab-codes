function k=Or8(x,y,z,k,l,m,n,o)
if x==0 
    if y==0
        if z==0 
           if k==0
               if l==0 
    if m==0
        if n==0 
           if o==0
   k=0;
else
   k=1;
           end
        end
    end
               end
           end
        end
    end
end
end
