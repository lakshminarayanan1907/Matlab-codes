function f=And3(x,y,z)
if x==1
    if y==1
        if z==1
        f=1;
    else 
        f=0;
        end
    end
end
end