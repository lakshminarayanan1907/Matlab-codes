clc;
clear;
function m=NOT(x)
if x==1
   m=0;
else
  m=1;
end
end