clc;
clear;
function k=OR(x,y)
if x==0 
    if y==0
   k=0;
else
   k=1;
    end
end
end
