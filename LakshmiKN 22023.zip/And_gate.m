clc;
clear;
function f=AND(x,y)
if x==1
    if y==1
        f=1;
    else 
        f=0;
    end
end
end