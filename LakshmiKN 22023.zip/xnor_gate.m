clc;
clear;
x=input("enter a binary number:");
y=input("enter a binary number:");
f=xor(x,y);
g=not(f);
g