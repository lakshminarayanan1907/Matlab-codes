function f=And4(x,y,z,r)
if x==1
    if y==1
        if z==1
           if r==1
        f=1;
    else 
        f=0;
           end 
        end
    end
end
end
